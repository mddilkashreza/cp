const List=[

    
    {  id:1, catName:"भिडियो" },
    {  id:2, catName:"ग्यालरी" },
    {  id:3, catName:"नयाँसूचना" },
    {  id:4, catName:"राजनीति" },
    {  id:5, catName:"प्रशासन" },
    {  id:6, catName:"समाज" },
    {  id:7, catName:"अपराध" },
    {  id:8, catName:"बिचार" },
    {  id:9, catName:"अन्तरवार्ता" },
    {  id:10, catName:"अर्थ" },
    {  id:11, catName:"विश्व" },
    {  id:12, catName:"खेल" },
    {  id:13, catName:"कला/साहित्य" },
    {  id:14, catName:"सम्पादकीय" },
    {  id:15, catName:"सूचना प्रविधि" },
    {  id:16, catName:"स्वास्थ्य, शिक्षा" },
    {  id:17, catName:"अध्यात्म/दर्शन" },
   
]
export default List;